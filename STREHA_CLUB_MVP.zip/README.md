# STREHA CLUB — MVP

Ky është një prototip statik për STREHA CLUB.
- `index.html` përmban faqen, stilimin dhe formularin.
- Formulari demonstron krijimin e një ID-je.
- Të dhënat nuk ruhen në server; për versionin real duhet backend/database.
- Mund të publikohet në GitHub Pages si një faqe të re ose në një folder `/club/` të website-it ekzistues.

## Versioni real
Hapat e rekomanduar:
1. Database për anëtarët.
2. Login/profil.
3. XP ledger.
4. Catch submission + moderim.
5. Leaderboard.
6. Rewards.
7. Admin panel për Streha.
